const $ = (s) => document.querySelector(s);
const messages = $("#messages");
const welcome = $("#welcome");
let busy = false;
let toastTimer;

function toast(message) {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 4200);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
}
function setBusy(value) {
  busy = value;
  $("#sendButton").disabled = value;
}
async function api(url, options = {}) {
  let response;
  try {
    response = await fetch(url, options);
  } catch {
    throw new Error("Cannot connect to the Folio server. Check that python main.py is still running, then refresh this page.");
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Server error (${response.status}).`);
  return data;
}
async function refreshStatus() {
  try {
    const data = await api("/api/status");
    const ready = Boolean(data.ready);
    $("#statusDot").classList.toggle("ready", ready);
    $("#topStatusDot").classList.toggle("ready", ready);
    $("#statusText").textContent = ready ? "Ready to answer" : "Knowledge not ready";
    $("#connectionText").textContent = ready ? "Ready" : "Waiting for knowledge index";
  } catch (error) {
    $("#statusText").textContent = "Server unavailable";
    $("#connectionText").textContent = "Connection unavailable";
  }
}
function appendMessage(role, content) {
  welcome.style.display = "none";
  const el = document.createElement("div");
  el.className = `message ${role}`;
  const avatar = role === "assistant" ? "✦" : "You";
  el.innerHTML = `<div class="avatar">${avatar}</div><div class="bubble">${escapeHtml(content)}</div>`;
  messages.appendChild(el);
  messages.scrollTop = messages.scrollHeight;
  return el;
}
async function ask(question) {
  if (!question || busy) return;
  appendMessage("user", question);
  $("#questionInput").value = "";
  $("#questionInput").style.height = "auto";
  const pending = appendMessage("assistant", "Thinking…");
  pending.querySelector(".bubble").classList.add("typing");
  setBusy(true);
  try {
    const data = await api("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({question})
    });
    pending.remove();
    appendMessage("assistant", data.answer || "No answer was returned.");
  } catch (error) {
    pending.remove();
    appendMessage("assistant", `I couldn't complete that request: ${error.message}`);
  } finally {
    setBusy(false);
    $("#questionInput").focus();
    await refreshStatus();
  }
}
$("#chatForm").addEventListener("submit", e => {
  e.preventDefault();
  ask($("#questionInput").value.trim());
});
$("#questionInput").addEventListener("input", e => {
  e.target.style.height = "auto";
  e.target.style.height = `${Math.min(e.target.scrollHeight, 140)}px`;
});
$("#questionInput").addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    $("#chatForm").requestSubmit();
  }
});
document.querySelectorAll("[data-question]").forEach(button => {
  button.addEventListener("click", () => ask(button.dataset.question));
});
$("#clearButton").addEventListener("click", () => {
  messages.innerHTML = "";
  welcome.style.display = "";
  toast("Conversation cleared.");
});
refreshStatus();
const textarea = document.getElementById('questionInput');

function autoResize() {
  textarea.style.height = 'auto';
  textarea.style.height = Math.min(textarea.scrollHeight, 180) + 'px';
}

textarea.addEventListener('input', autoResize);
autoResize();