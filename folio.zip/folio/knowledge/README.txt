Helper file only. Folio AI intentionally excludes README.txt from indexing and the visible knowledge library.
